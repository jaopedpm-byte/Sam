package com.meu.assistente

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bubble: FaceView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var panel: LinearLayout? = null
    private lateinit var voice: Voice
    private lateinit var brain: Brain
    private val handler = Handler(Looper.getMainLooper())
    private val idleRunnable = Runnable { if (this::bubble.isInitialized) bubble.mode = FaceView.Mode.IDLE }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addBubble()
        voice = Voice(
            this,
            onResult = { text -> bubble.mode = FaceView.Mode.IDLE; toast("Você: $text"); brain.handle(text) },
            onState = { s ->
                if (s == "Ouvindo…") bubble.mode = FaceView.Mode.LISTENING
                else { bubble.mode = FaceView.Mode.IDLE; toast(s) }
            },
            onSpeaking = { sp -> bubble.mode = if (sp) FaceView.Mode.SPEAKING else FaceView.Mode.IDLE }
        )
        brain = Brain(this) { reply ->
            toast(reply)
            voice.speak(reply)
            // plano B: se a voz do celular não falar, o rosto volta ao normal sozinho
            bubble.mode = FaceView.Mode.SPEAKING
            handler.removeCallbacks(idleRunnable)
            handler.postDelayed(idleRunnable, 1200L + reply.length * 80L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "LISTEN") handler.post { bubble.mode = FaceView.Mode.LISTENING; voice.listen() }
        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { wm.removeView(bubble) }
        hidePanel()
        voice.shutdown()
        super.onDestroy()
    }

    // ---------- notificação (única parte visível na tela de bloqueio) ----------
    private fun startAsForeground() {
        val ch = "assistente"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Assistente", NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            })
        val listen = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction("LISTEN"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Assistente ativo")
            .setContentText("Toque em Ouvir para falar comigo")
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "🎤 Ouvir", listen).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    // ---------- botão flutuante ----------
    private fun addBubble() {
        val size = dp(80)
        bubble = FaceView(this)
        bubbleLp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 400 }

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = bubbleLp.x; sy = bubbleLp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { bubbleLp.x = sx + dx; bubbleLp.y = sy + dy; wm.updateViewLayout(bubble, bubbleLp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) { if (panel == null) showPanel() else hidePanel() }
                }
                return true
            }
        })
        wm.addView(bubble, bubbleLp)
    }

    // ---------- painel: digitar ou ouvir ----------
    private fun showPanel() {
        val input = EditText(this).apply {
            hint = "Digite um comando…"; setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        input.setOnEditorActionListener { _, _, _ -> submit(input.text.toString()); true }
        val row = LinearLayout(this).apply {
            addView(Button(context).apply { text = "Enviar"; setOnClickListener { submit(input.text.toString()) } })
            addView(Button(context).apply { text = "🎤 Ouvir"; setOnClickListener { hidePanel(); bubble.mode = FaceView.Mode.LISTENING; voice.listen() } })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(20).toFloat() }
            elevation = 12f
            addView(input); addView(row)
        }
        val lp = WindowManager.LayoutParams(
            dp(320), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(120)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(box, lp)
        panel = box
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    private fun submit(text: String) {
        if (text.isBlank()) return
        hidePanel()  // devolve o foco ao app de baixo antes de agir nele
        handler.postDelayed({ brain.handle(text) }, 500)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
