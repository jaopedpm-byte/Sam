package com.meu.assistente

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Rosto preto com olhos e boca em néon, animado. */
class FaceView(ctx: Context) : View(ctx) {
    enum class Mode { IDLE, LISTENING, SPEAKING }

    var mode: Mode = Mode.IDLE
        set(v) { field = v; invalidate() }

    private var phase = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun blend(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** Desenha duas vezes: brilho borrado por baixo + núcleo claro por cima = efeito néon. */
    private fun neon(color: Int, sw: Float, draw: () -> Unit) {
        p.maskFilter = BlurMaskFilter(sw * 1.6f, BlurMaskFilter.Blur.NORMAL)
        p.color = color; p.strokeWidth = sw * 1.8f; draw()
        p.maskFilter = null
        p.color = blend(color, Color.WHITE, 0.55f); p.strokeWidth = sw * 0.7f; draw()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val r = w / 2f - w * 0.12f
        val color = when (mode) {
            Mode.IDLE -> 0xFF00F0FF.toInt()
            Mode.LISTENING -> 0xFF39FF14.toInt()
            Mode.SPEAKING -> 0xFFFF2DF1.toInt()
        }
        val sw = w * 0.045f
        val pulse = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat())

        c.drawCircle(cx, h / 2f, r, bg)
        neon(color, sw * (if (mode == Mode.LISTENING) 0.8f + 0.5f * pulse else 1f)) { c.drawCircle(cx, h / 2f, r, p) }

        // olhos (piscam de vez em quando)
        val blink = if (phase in 0.90f..0.96f) abs((phase - 0.93f) / 0.03f).coerceIn(0.08f, 1f) else 1f
        val ex = w * 0.22f; val ey = h * 0.40f
        val hh = h * 0.11f * blink * (if (mode == Mode.LISTENING) 1.25f else 1f)
        neon(color, sw) {
            c.drawLine(cx - ex, ey - hh, cx - ex, ey + hh, p)
            c.drawLine(cx + ex, ey - hh, cx + ex, ey + hh, p)
        }

        // boca
        when (mode) {
            Mode.IDLE -> neon(color, sw) {
                c.drawArc(RectF(cx - w * 0.20f, h * 0.50f, cx + w * 0.20f, h * 0.74f), 25f, 130f, false, p)
            }
            Mode.SPEAKING -> {
                val open = 0.5f + 0.5f * sin(phase * 2f * PI.toFloat() * 10f)
                val mh = h * (0.03f + 0.12f * open)
                neon(color, sw) { c.drawOval(RectF(cx - w * 0.14f, h * 0.66f - mh, cx + w * 0.14f, h * 0.66f + mh), p) }
            }
            Mode.LISTENING -> neon(color, sw) {
                c.drawCircle(cx, h * 0.67f, w * (0.05f + 0.03f * pulse), p)
            }
        }
    }
}
