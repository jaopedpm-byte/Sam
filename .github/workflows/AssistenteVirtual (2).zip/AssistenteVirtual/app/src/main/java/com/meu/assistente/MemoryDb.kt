package com.meu.assistente

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Banco local no próprio celular: memórias (frases que você ensinou) + histórico. */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "assistente.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT, norm TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT, said TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) = onCreate(db)

    fun remember(text: String) {
        val norm = Text.fold(text).trim()
        readableDatabase.rawQuery("SELECT id FROM memories WHERE norm=?", arrayOf(norm)).use {
            if (it.moveToFirst()) return
        }
        writableDatabase.execSQL(
            "INSERT INTO memories(text, norm, ts) VALUES(?,?,?)",
            arrayOf(text.trim(), norm, System.currentTimeMillis())
        )
    }

    /** Todas as memórias, da mais recente para a mais antiga: (id, texto). */
    fun rows(): List<Pair<Long, String>> {
        val out = ArrayList<Pair<Long, String>>()
        readableDatabase.rawQuery("SELECT id, text FROM memories ORDER BY ts DESC LIMIT 3000", null).use {
            while (it.moveToNext()) out.add(Pair(it.getLong(0), it.getString(1)))
        }
        return out
    }

    fun forget(id: Long) {
        writableDatabase.execSQL("DELETE FROM memories WHERE id=?", arrayOf(id))
    }

    fun log(said: String) {
        writableDatabase.execSQL("INSERT INTO history(said, ts) VALUES(?,?)", arrayOf(said, System.currentTimeMillis()))
    }
}
