package com.meu.assistente

import java.text.Normalizer

/** Ferramentas de texto: palavras-chave, comparação e troca de "meu" por "seu". */
object Text {
    fun fold(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private val stop = listOf(
        "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "da", "do", "das", "dos", "em", "na", "no", "nas", "nos",
        "e", "é", "que", "qual", "quais", "quem", "onde", "quando", "como", "quanto", "quantos", "quantas", "por", "para",
        "pra", "com", "se", "me", "te", "eu", "você", "voce", "tu", "ser", "sou", "são", "foi", "está", "esta", "estou",
        "tem", "sobre", "meu", "minha", "meus", "minhas", "seu", "sua", "seus", "suas", "isso", "isto", "aquilo", "ao",
        "à", "ou", "mais", "muito", "sabe", "lembra", "diga", "fale", "falar", "dizer", "conta", "ele", "ela", "eles",
        "elas", "já", "não", "sim", "aprenda", "aprende", "lembre", "anote", "guarde", "memorize", "saiba", "porque"
    ).map { fold(it) }.toSet()

    fun tokens(s: String): Set<String> =
        fold(s).split(Regex("[^a-z0-9]+")).filter { it.length >= 2 && it !in stop }.toSet()

    /** Palavras parecidas (gosto/gosta, gato/gatos). */
    fun similar(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return i >= 4 && i >= minOf(a.length, b.length) - 1
    }

    private val swaps = listOf(
        "eu sou" to "você é", "eu estou" to "você está", "meus" to "seus", "minhas" to "suas",
        "meu" to "seu", "minha" to "sua", "mim" to "você", "eu" to "você"
    ).map { Regex("(?<![\\p{L}])${it.first}(?![\\p{L}])", RegexOption.IGNORE_CASE) to it.second }

    fun toSecondPerson(s: String): String {
        var out = s
        for ((re, rep) in swaps) out = re.replace(out, rep)
        return out
    }
}
