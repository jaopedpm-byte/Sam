package com.meu.assistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, p)
        }
        fun btn(label: String, action: () -> Unit) {
            col.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }
        col.addView(TextView(this).apply {
            text = "Assistente Virtual v0.2\n\nSiga os passos na ordem:\n"
            textSize = 18f
        })
        btn("1. Permitir sobreposição na tela") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Ativar serviço de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Permitir microfone e notificações") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("4. Iniciar assistente") {
            when {
                !Settings.canDrawOverlays(this) ->
                    Toast.makeText(this, "Falta o passo 1", Toast.LENGTH_LONG).show()
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    Toast.makeText(this, "Falta o passo 3", Toast.LENGTH_LONG).show()
                else -> startForegroundService(Intent(this, FloatingService::class.java))
            }
        }
        btn("Parar assistente") { stopService(Intent(this, FloatingService::class.java)) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
