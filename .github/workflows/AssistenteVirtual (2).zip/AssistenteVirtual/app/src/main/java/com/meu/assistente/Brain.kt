package com.meu.assistente

import android.accessibilityservice.AccessibilityService
import android.content.Context

/** Entende o que você diz: ensina (grava na memória), pergunta (busca por palavras) e age na tela. */
class Brain(ctx: Context, private val say: (String) -> Unit) {
    private val db = MemoryDb(ctx)

    private val question = Regex(
        "^(qual|quais|quem|o que|oque|onde|quando|como|quanto|quantos|quantas|por que|porque|" +
            "você sabe|voce sabe|você lembra|voce lembra|lembra|me diga|me fale|fale sobre|me conta)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun arg(t: String, vararg prefixes: String): String? {
        val l = t.lowercase()
        for (p in prefixes) if (l.startsWith(p)) return t.substring(p.length).trim()
        return null
    }

    /** Memórias mais parecidas com as palavras da pergunta. */
    private fun rank(q: Set<String>, limit: Int): List<Pair<Long, String>> {
        if (q.isEmpty()) return emptyList()
        val scored = db.rows().map { row ->
            val toks = Text.tokens(row.second)
            row to q.count { w -> toks.any { Text.similar(w, it) } }
        }
        val top = scored.maxOfOrNull { it.second } ?: 0
        if (top == 0) return emptyList()
        return scored.filter { it.second == top }.take(limit).map { it.first }
    }

    private fun ask(t: String) {
        val q = Text.tokens(t)
        if (q.isEmpty()) { say("Sobre o que você quer saber?"); return }
        val hits = rank(q, 2)
        if (hits.isEmpty()) say("Ainda não tenho nada guardado sobre isso. Me conte e eu guardo.")
        else say(hits.joinToString(". ") { Text.toSecondPerson(it.second) })
    }

    fun handle(raw: String) {
        val t = raw.trim().trimEnd('.', '!', '?', ',')
        if (t.isEmpty()) return
        val l = t.lowercase()
        db.log(t)
        val acc = AssistantAccessibilityService.instance

        if (l in setOf("oi", "olá", "ola", "bom dia", "boa tarde", "boa noite", "e aí", "eai")) {
            say("Olá! Me conte coisas para eu guardar, ou me pergunte."); return
        }

        // --- esquecer ---
        arg(t, "esqueça que ", "esqueça ", "esquece ", "apague ")?.let { x ->
            val hits = rank(Text.tokens(x), 5)
            hits.forEach { db.forget(it.first) }
            say(if (hits.isEmpty()) "Não achei nada sobre isso na memória" else "Pronto, esqueci ${hits.size} coisa(s)")
            return
        }

        // --- perguntas: busca na memória pelas palavras-chave ---
        if (question.containsMatchIn(l)) { ask(t); return }

        // --- fala ---
        arg(t, "fale ", "diga ")?.let { say(it); return }

        // --- ações na tela (precisam de acessibilidade) ---
        val needsAcc = l.startsWith("clique em ") || l.startsWith("toque em ") || l.startsWith("aperte ") ||
            l.startsWith("digite ") || l.startsWith("escreva ") || l in setOf(
            "voltar", "início", "inicio", "home", "tela inicial", "recentes", "notificações",
            "role para baixo", "role para cima", "leia a tela"
        )
        if (needsAcc && acc == null) { say("Ative o serviço de acessibilidade do assistente"); return }
        if (acc != null) {
            arg(t, "clique em ", "toque em ", "aperte ")?.let {
                say(if (acc.clickByText(it)) "Cliquei em $it" else "Não achei $it na tela"); return
            }
            arg(t, "digite ", "escreva ")?.let {
                say(if (acc.typeText(it)) "Digitei" else "Nenhum campo de texto selecionado"); return
            }
            when (l) {
                "voltar" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); return }
                "início", "inicio", "home", "tela inicial" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return }
                "recentes" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); return }
                "notificações" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); return }
                "role para baixo" -> { acc.scroll(true); return }
                "role para cima" -> { acc.scroll(false); return }
                "leia a tela" -> { say(acc.screenText().take(500).ifBlank { "Não vi texto na tela" }); return }
            }
        }

        // --- qualquer outra frase é algo que você está me ensinando ---
        val fact = arg(
            t, "aprenda que ", "aprende que ", "aprenda ", "aprende ", "lembre-se de que ", "lembre-se que ",
            "lembre que ", "memorize que ", "memorize ", "anote que ", "anote ", "guarde que ", "guarde ", "saiba que "
        ) ?: t
        if (Text.tokens(fact).size < 2) {
            say("Não entendi. Me conte uma frase, por exemplo: meu nome é João"); return
        }
        db.remember(fact)
        say("Guardei: ${Text.toSecondPerson(fact)}")
    }
}
